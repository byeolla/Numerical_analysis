# Version
* python 3.10.4
* NumPy 1.23.1
* matplotlib 3.5.2
* pandas 1.4.4


```python
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
```


```python
def euler_method(f, g, t0, tN, y0, h):
    N = int((tN - t0)/h)
    grid = np.linspace(t0, tN, N+1)
    ygrid = np.zeros_like(grid)
    ygrid[0] = y0
    iter = np.arange(0, N+1)
    for i in iter:
        try:
            slope = f(grid[i], ygrid[i])
            ygrid[i+1] = ygrid[i] + slope * h
        except:
            break
    exact = g(grid)
    df = pd.DataFrame({"Iteration": iter, "t": grid, "Euler Approx":ygrid, "Exact": exact, "Error":ygrid-exact})
    return df, grid, ygrid, exact

```

# Problem 1

$$y^{\prime} = \frac{1}{y^{2}}, y(0)=1$$
$$\text{exact solution} \quad y=\sqrt[3]{1+3t}$$


```python
f = lambda t, y: 1/(y**2)
g = lambda t:(1+3*t)**(1/3)
u, grid, ygrid, exact = euler_method(f,g, 0, 1, 1, 0.1)
plt.plot(grid, ygrid, label="Euler Approximation", c="C1")
plt.plot(grid, exact, label="Exact Solution $y=\sqrt[3]{1+3t}$", c="C2")
plt.legend()
plt.show()
u.set_index("Iteration")



```


    
![png](output_4_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>t</th>
      <th>Euler Approx</th>
      <th>Exact</th>
      <th>Error</th>
    </tr>
    <tr>
      <th>Iteration</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.1</td>
      <td>1.100000</td>
      <td>1.091393</td>
      <td>0.008607</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.2</td>
      <td>1.182645</td>
      <td>1.169607</td>
      <td>0.013038</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.3</td>
      <td>1.254142</td>
      <td>1.238562</td>
      <td>0.015580</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.4</td>
      <td>1.317720</td>
      <td>1.300591</td>
      <td>0.017129</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.5</td>
      <td>1.375311</td>
      <td>1.357209</td>
      <td>0.018102</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.6</td>
      <td>1.428180</td>
      <td>1.409460</td>
      <td>0.018720</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.7</td>
      <td>1.477207</td>
      <td>1.458100</td>
      <td>0.019107</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.8</td>
      <td>1.523033</td>
      <td>1.503695</td>
      <td>0.019339</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.9</td>
      <td>1.566143</td>
      <td>1.546680</td>
      <td>0.019463</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1.0</td>
      <td>1.606913</td>
      <td>1.587401</td>
      <td>0.019512</td>
    </tr>
  </tbody>
</table>
</div>



# Problem 2

$$ y^{\prime} = t + y, y(0) = 0$$
$$\text{exact solution} \quad y = -(t+1) + 2e^{-t}$$


```python
f = lambda t, y : t+y ; f0 = 0
g = lambda t : -(t+1) + np.exp(t)
```

## h = 0.1


```python
u, grid, approx, exact = euler_method(f, g, 0, 1, f0, 0.1)
plt.plot(grid, approx, label="Euler Approximation", c="C1")
plt.plot(grid, exact, label="Exact Solution $y=-(t+1)+2e^{t}$", c="C2")
plt.legend()
plt.show()
u.set_index("Iteration")

```


    
![png](output_8_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>t</th>
      <th>Euler Approx</th>
      <th>Exact</th>
      <th>Error</th>
    </tr>
    <tr>
      <th>Iteration</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.1</td>
      <td>0.000000</td>
      <td>0.005171</td>
      <td>-0.005171</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.2</td>
      <td>0.010000</td>
      <td>0.021403</td>
      <td>-0.011403</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.3</td>
      <td>0.031000</td>
      <td>0.049859</td>
      <td>-0.018859</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.4</td>
      <td>0.064100</td>
      <td>0.091825</td>
      <td>-0.027725</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.5</td>
      <td>0.110510</td>
      <td>0.148721</td>
      <td>-0.038211</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.6</td>
      <td>0.171561</td>
      <td>0.222119</td>
      <td>-0.050558</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.7</td>
      <td>0.248717</td>
      <td>0.313753</td>
      <td>-0.065036</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.8</td>
      <td>0.343589</td>
      <td>0.425541</td>
      <td>-0.081952</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.9</td>
      <td>0.457948</td>
      <td>0.559603</td>
      <td>-0.101655</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1.0</td>
      <td>0.593742</td>
      <td>0.718282</td>
      <td>-0.124539</td>
    </tr>
  </tbody>
</table>
</div>



## h = 0.05


```python
u, grid, approx, exact = euler_method(f, g, 0, 1, f0, 0.05)
plt.plot(grid, approx, label="Euler Approximation", c="C1")
plt.plot(grid, exact, label="Exact Solution $y=-(t+1)+2e^{t}$", c="C2")
plt.legend()
plt.show()
u.set_index("Iteration")
```


    
![png](output_10_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>t</th>
      <th>Euler Approx</th>
      <th>Exact</th>
      <th>Error</th>
    </tr>
    <tr>
      <th>Iteration</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.05</td>
      <td>0.000000</td>
      <td>0.001271</td>
      <td>-0.001271</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.10</td>
      <td>0.002500</td>
      <td>0.005171</td>
      <td>-0.002671</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.15</td>
      <td>0.007625</td>
      <td>0.011834</td>
      <td>-0.004209</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.20</td>
      <td>0.015506</td>
      <td>0.021403</td>
      <td>-0.005897</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.25</td>
      <td>0.026282</td>
      <td>0.034025</td>
      <td>-0.007744</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.30</td>
      <td>0.040096</td>
      <td>0.049859</td>
      <td>-0.009763</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.35</td>
      <td>0.057100</td>
      <td>0.069068</td>
      <td>-0.011967</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.40</td>
      <td>0.077455</td>
      <td>0.091825</td>
      <td>-0.014369</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.45</td>
      <td>0.101328</td>
      <td>0.118312</td>
      <td>-0.016984</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.50</td>
      <td>0.128895</td>
      <td>0.148721</td>
      <td>-0.019827</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.55</td>
      <td>0.160339</td>
      <td>0.183253</td>
      <td>-0.022914</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.60</td>
      <td>0.195856</td>
      <td>0.222119</td>
      <td>-0.026262</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.65</td>
      <td>0.235649</td>
      <td>0.265541</td>
      <td>-0.029892</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.70</td>
      <td>0.279932</td>
      <td>0.313753</td>
      <td>-0.033821</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.75</td>
      <td>0.328928</td>
      <td>0.367000</td>
      <td>-0.038072</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.80</td>
      <td>0.382875</td>
      <td>0.425541</td>
      <td>-0.042666</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.85</td>
      <td>0.442018</td>
      <td>0.489647</td>
      <td>-0.047629</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.90</td>
      <td>0.506619</td>
      <td>0.559603</td>
      <td>-0.052984</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.95</td>
      <td>0.576950</td>
      <td>0.635710</td>
      <td>-0.058759</td>
    </tr>
    <tr>
      <th>20</th>
      <td>1.00</td>
      <td>0.653298</td>
      <td>0.718282</td>
      <td>-0.064984</td>
    </tr>
  </tbody>
</table>
</div>



## h = 0.025


```python
u, grid, approx, exact = euler_method(f, g, 0, 1, f0, 0.025)
plt.plot(grid, approx, label="Euler Approximation", c="C1")
plt.plot(grid, exact, label="Exact Solution $y=-(t+1)+2e^{t}$", c="C2")
plt.legend()
plt.show()
u.set_index("Iteration")
```


    
![png](output_12_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>t</th>
      <th>Euler Approx</th>
      <th>Exact</th>
      <th>Error</th>
    </tr>
    <tr>
      <th>Iteration</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.025</td>
      <td>0.000000</td>
      <td>0.000315</td>
      <td>-0.000315</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.050</td>
      <td>0.000625</td>
      <td>0.001271</td>
      <td>-0.000646</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.075</td>
      <td>0.001891</td>
      <td>0.002884</td>
      <td>-0.000994</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.100</td>
      <td>0.003813</td>
      <td>0.005171</td>
      <td>-0.001358</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.125</td>
      <td>0.006408</td>
      <td>0.008148</td>
      <td>-0.001740</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.150</td>
      <td>0.009693</td>
      <td>0.011834</td>
      <td>-0.002141</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.175</td>
      <td>0.013686</td>
      <td>0.016246</td>
      <td>-0.002560</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.200</td>
      <td>0.018403</td>
      <td>0.021403</td>
      <td>-0.003000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.225</td>
      <td>0.023863</td>
      <td>0.027323</td>
      <td>-0.003460</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.250</td>
      <td>0.030085</td>
      <td>0.034025</td>
      <td>-0.003941</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.275</td>
      <td>0.037087</td>
      <td>0.041531</td>
      <td>-0.004444</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.300</td>
      <td>0.044889</td>
      <td>0.049859</td>
      <td>-0.004970</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.325</td>
      <td>0.053511</td>
      <td>0.059031</td>
      <td>-0.005520</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.350</td>
      <td>0.062974</td>
      <td>0.069068</td>
      <td>-0.006094</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.375</td>
      <td>0.073298</td>
      <td>0.079991</td>
      <td>-0.006693</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.400</td>
      <td>0.084506</td>
      <td>0.091825</td>
      <td>-0.007319</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.425</td>
      <td>0.096618</td>
      <td>0.104590</td>
      <td>-0.007972</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.450</td>
      <td>0.109659</td>
      <td>0.118312</td>
      <td>-0.008653</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.475</td>
      <td>0.123650</td>
      <td>0.133014</td>
      <td>-0.009364</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.500</td>
      <td>0.138616</td>
      <td>0.148721</td>
      <td>-0.010105</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.525</td>
      <td>0.154582</td>
      <td>0.165459</td>
      <td>-0.010877</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.550</td>
      <td>0.171571</td>
      <td>0.183253</td>
      <td>-0.011682</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.575</td>
      <td>0.189611</td>
      <td>0.202131</td>
      <td>-0.012520</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.600</td>
      <td>0.208726</td>
      <td>0.222119</td>
      <td>-0.013393</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.625</td>
      <td>0.228944</td>
      <td>0.243246</td>
      <td>-0.014302</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.650</td>
      <td>0.250293</td>
      <td>0.265541</td>
      <td>-0.015248</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.675</td>
      <td>0.272800</td>
      <td>0.289033</td>
      <td>-0.016233</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.700</td>
      <td>0.296495</td>
      <td>0.313753</td>
      <td>-0.017258</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.725</td>
      <td>0.321407</td>
      <td>0.339731</td>
      <td>-0.018324</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.750</td>
      <td>0.347568</td>
      <td>0.367000</td>
      <td>-0.019432</td>
    </tr>
    <tr>
      <th>31</th>
      <td>0.775</td>
      <td>0.375007</td>
      <td>0.395592</td>
      <td>-0.020585</td>
    </tr>
    <tr>
      <th>32</th>
      <td>0.800</td>
      <td>0.403757</td>
      <td>0.425541</td>
      <td>-0.021784</td>
    </tr>
    <tr>
      <th>33</th>
      <td>0.825</td>
      <td>0.433851</td>
      <td>0.456881</td>
      <td>-0.023030</td>
    </tr>
    <tr>
      <th>34</th>
      <td>0.850</td>
      <td>0.465322</td>
      <td>0.489647</td>
      <td>-0.024325</td>
    </tr>
    <tr>
      <th>35</th>
      <td>0.875</td>
      <td>0.498205</td>
      <td>0.523875</td>
      <td>-0.025670</td>
    </tr>
    <tr>
      <th>36</th>
      <td>0.900</td>
      <td>0.532535</td>
      <td>0.559603</td>
      <td>-0.027068</td>
    </tr>
    <tr>
      <th>37</th>
      <td>0.925</td>
      <td>0.568349</td>
      <td>0.596868</td>
      <td>-0.028520</td>
    </tr>
    <tr>
      <th>38</th>
      <td>0.950</td>
      <td>0.605682</td>
      <td>0.635710</td>
      <td>-0.030027</td>
    </tr>
    <tr>
      <th>39</th>
      <td>0.975</td>
      <td>0.644574</td>
      <td>0.676167</td>
      <td>-0.031593</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1.000</td>
      <td>0.685064</td>
      <td>0.718282</td>
      <td>-0.033218</td>
    </tr>
  </tbody>
</table>
</div>


